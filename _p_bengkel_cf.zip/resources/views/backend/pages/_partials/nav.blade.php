<nav class="nav flex-column">
  <a class="nav-link active" href="{{route('bobot.index')}}">Bobot Nilai</a>
  <a class="nav-link active" href="{{route('gejala.index')}}">Gejala</a>
  <a class="nav-link active" href="{{route('solusi.index')}}">Perbaikan</a>
  <a class="nav-link active" href="{{route('perbaikan.index')}}">Hubungan</a>
</nav>